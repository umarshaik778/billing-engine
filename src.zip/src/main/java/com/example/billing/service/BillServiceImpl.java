package com.example.billing.service;

import com.example.billing.component.ProcessingGate;
import com.example.billing.enums.PayloadFormat;
import com.example.billing.exception.InvalidBillException;
import com.example.billing.model.input.BillInput;
import com.example.billing.model.output.BillOutput;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class BillServiceImpl implements BillService {

    private static final Logger requestLog =
            LoggerFactory.getLogger("REQUEST_LOG");
    private static final Logger successLog =
            LoggerFactory.getLogger("SUCCESS_LOG");

    /* ================= DIRECTORIES ================= */

    private static final Path BASE = Paths.get("data");
    private static final Path PROCESSING = BASE.resolve("processing");
    private static final Path FAILED = BASE.resolve("failed");
    private static final Path REPLAY = BASE.resolve("replay");
    private static final Path SUCCESS_IN = BASE.resolve("success/input");
    private static final Path SUCCESS_OUT = BASE.resolve("success/output");

    /* ================= DEPENDENCIES ================= */

    private final RuleEngine ruleEngine = new RuleEngine();
    private final ProcessingGate gate;

    private final XmlMapper xmlMapper = new XmlMapper();
    private final ObjectMapper jsonMapper = new ObjectMapper();

    public BillServiceImpl(ProcessingGate gate) {
        this.gate = gate;
    }

    /* ================= INIT ================= */

    @PostConstruct
    public void init() {
        try {
            Files.createDirectories(PROCESSING);
            Files.createDirectories(FAILED);
            Files.createDirectories(REPLAY);
            Files.createDirectories(SUCCESS_IN);
            Files.createDirectories(SUCCESS_OUT);
        } catch (Exception ex) {
            throw new IllegalStateException("Directory init failed", ex);
        }
    }

    /* ================= MAIN PROCESS ================= */

    @Override
    public BillOutput process(
            BillInput input,
            PayloadFormat inputFormat,
            PayloadFormat outputFormat
    ) {

        String baseName = buildBaseName(input.getHeader().getAccountNo());
        Path processingFile = null;

        try {
            processingFile = persistInput(
                    baseName, input, inputFormat
            );

            if (!gate.isEnabled()) {
                Files.move(
                        processingFile,
                        REPLAY.resolve(processingFile.getFileName()),
                        StandardCopyOption.REPLACE_EXISTING
                );

                requestLog.info(
                        "PROCESSING_SKIPPED | moved to replay | {}",
                        processingFile.getFileName()
                );
                return null;
            }

            BillOutput output = ruleEngine.applyRules(input);

            persistOutput(
                    baseName, output, outputFormat
            );

            Files.move(
                    processingFile,
                    SUCCESS_IN.resolve(processingFile.getFileName()),
                    StandardCopyOption.ATOMIC_MOVE
            );

            successLog.info(
                    "PROCESSING_SUCCESS | account={}",
                    input.getHeader().getAccountNo()
            );

            return output;

        } catch (Exception ex) {

            safeMove(processingFile, FAILED);
            throw new InvalidBillException("Processing failed", ex);
        }
    }

    /* ================= REPLAY ================= */

    @Override
    public BillOutput replay(
            BillInput input,
            PayloadFormat format,
            Path processingFile
    ) {

        try {
            BillOutput output = ruleEngine.applyRules(input);

            persistOutput(
                    input.getHeader().getAccountNo(),
                    output,
                    format
            );

            Files.move(
                    processingFile,
                    SUCCESS_IN.resolve(processingFile.getFileName()),
                    StandardCopyOption.ATOMIC_MOVE
            );

            return output;

        } catch (Exception ex) {
            safeMove(processingFile, FAILED);
            throw new InvalidBillException("Replay failed", ex);
        }
    }

    /* ================= STORAGE ================= */

    private Path persistInput(
            String base,
            BillInput input,
            PayloadFormat format
    ) throws Exception {

        String name = fileName(base, "IN", format);
        Path path = PROCESSING.resolve(name);

        if (format == PayloadFormat.XML)
            xmlMapper.writeValue(path.toFile(), input);
        else
            jsonMapper.writeValue(path.toFile(), input);

        requestLog.info("INPUT_STORED | {}", path);
        return path;
    }

    private void persistOutput(
            String base,
            BillOutput output,
            PayloadFormat format
    ) throws Exception {

        String name = fileName(base, "OUT", format);
        Path path = SUCCESS_OUT.resolve(name);

        if (format == PayloadFormat.XML)
            xmlMapper.writeValue(path.toFile(), output);
        else
            jsonMapper.writeValue(path.toFile(), output);
    }

    /* ================= UTIL ================= */

    private void safeMove(Path src, Path destDir) {
        try {
            if (src != null && Files.exists(src)) {
                Files.move(
                        src,
                        destDir.resolve(src.getFileName()),
                        StandardCopyOption.REPLACE_EXISTING
                );
            }
        } catch (Exception ignored) {}
    }

    private String buildBaseName(String acc) {
        return acc + "_" +
                LocalDateTime.now()
                        .format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
    }

    private String fileName(
            String base,
            String type,
            PayloadFormat format
    ) {
        return base + "_" + type +
                (format == PayloadFormat.XML ? ".xml" : ".json");
    }
}
