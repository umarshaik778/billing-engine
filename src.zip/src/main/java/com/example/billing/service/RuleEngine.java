package com.example.billing.service;

import com.example.billing.model.audit.AuditTrail;
import com.example.billing.model.input.BillInput;
import com.example.billing.model.output.BillOutput;
import com.example.billing.model.output.MeterOutput;

import java.util.*;

public class RuleEngine {

    public BillOutput applyRules(BillInput input) {

        BillOutput output = new BillOutput();
        AuditTrail audit = new AuditTrail();

        audit.setTransformationId(UUID.randomUUID().toString());

        /* ================= BASIC MAPPING ================= */

        output.setAccountNumber(input.getHeader().getAccountNo());
        output.setBillingDate(input.getHeader().getIssueDate());
        output.setJurisdiction(input.getHeader().getJurisdiction());

        Map<String, String> mappings = new HashMap<>();
        mappings.put("header.accountNo", "accountNumber");
        mappings.put("header.issueDate", "billingDate");
        mappings.put("header.jurisdiction", "jurisdiction");
        audit.setFieldMappings(mappings);

        /* ================= RULE 1: MULTI-TIER DELIVERY ================= */

        double tier1 = 0, tier2 = 0, tier3 = 0;
        List<MeterOutput> meters = new ArrayList<>();
        double totalUsage = 0;

        for (BillInput.ServicePoint sp : input.getHeader().getServicePoints()) {
            for (BillInput.Meter meter : sp.getMeters()) {
                for (BillInput.Reading r : meter.getReadings()) {

                    double usage = r.getUsageKwh();
                    totalUsage += usage;

                    meters.add(new MeterOutput(
                            meter.getId(),
                            usage,
                            r.getRateTier()
                    ));

                    if (usage <= 500) {
                        tier1 += usage * 0.05;
                    } else if (usage <= 2000) {
                        tier2 += usage * 0.07;
                    } else {
                        tier3 += usage * 0.09;
                    }
                }
            }
        }

        Map<String, Double> delivery = new HashMap<>();
        delivery.put("tier1_0_500", tier1);
        delivery.put("tier2_501_2000", tier2);
        delivery.put("tier3_2001_plus", tier3);


        double baseCharges = tier1 + tier2 + tier3;
        output.setDeliveryCharges(delivery);
        output.setTotalBaseCharges(baseCharges);

        /* ================= RULE 2–4: TAXES ================= */

        double nyStateTax = baseCharges * 0.08875;
        double nycTax = "NYC".equalsIgnoreCase(output.getJurisdiction())
                ? baseCharges * 0.045 : 0;
        double mtaTax = baseCharges * 0.00375;

        Map<String, Double> taxes = new HashMap<>();
        taxes.put("nyStateTax", nyStateTax);
        taxes.put("nycLocalTax", nycTax);
        taxes.put("mtaSurcharge", mtaTax);


        output.setTaxBreakdown(taxes);

        /* ================= RULE 5: PROMO ================= */

        double promo = totalUsage > 10000 ? baseCharges * 0.02 : 0;

        /* ================= RULE 6: LATE FEE (SIMULATED) ================= */

        double lateFee = baseCharges * 0.015;
        output.setLateFee(lateFee);

        /* ================= FINAL TOTAL ================= */

        double totalDue =
                baseCharges +
                        nyStateTax +
                        nycTax +
                        mtaTax +
                        lateFee -
                        promo;

        output.setTotalDue(totalDue);
        output.setMeters(meters);

        audit.setFormulaApplications(List.of(
                "Tiered pricing",
                "NY State tax",
                "NYC tax",
                "MTA surcharge",
                "Late fee",
                "Promotional credit"
        ));

        output.setAuditTrail(audit);
        return output;
    }
}
