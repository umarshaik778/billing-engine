package com.example.billing.controller;

import com.example.billing.enums.PayloadFormat;
import com.example.billing.model.input.BillInput;
import com.example.billing.model.output.BillOutput;
import com.example.billing.service.BillService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bill")
public class BillController {

    private final BillService billService;

    public BillController(BillService billService) {
        this.billService = billService;
    }

    @PostMapping(
            value = "/process",
            consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE },
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE }
    )
    public BillOutput process(
            @RequestParam("inputFormat") PayloadFormat inputFormat,
            @RequestParam("outputFormat") PayloadFormat outputFormat,
            @RequestBody BillInput input
    ) {
        return billService.process(input, inputFormat, outputFormat);
    }
}
