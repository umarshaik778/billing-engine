package com.example.billing.model.output;

public class MeterOutput {

    private String meterId;
    private double usageKwh;
    private String rateTier;

    public MeterOutput(String meterId, double usageKwh, String rateTier) {
        this.meterId = meterId;
        this.usageKwh = usageKwh;
        this.rateTier = rateTier;
    }

    public String getMeterId() {
        return meterId;
    }

    public double getUsageKwh() {
        return usageKwh;
    }

    public String getRateTier() {
        return rateTier;
    }
}
