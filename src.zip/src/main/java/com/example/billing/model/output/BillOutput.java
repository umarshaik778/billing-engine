package com.example.billing.model.output;

import com.example.billing.model.audit.AuditTrail;
import java.util.List;
import java.util.Map;

public class BillOutput {

    private String accountNumber;
    private String billingDate;
    private String jurisdiction;

    private double totalBaseCharges;
    private double totalDue;

    private Map<String, Double> taxBreakdown;
    private Map<String, Double> deliveryCharges;

    private double lateFee;

    private List<MeterOutput> meters;

    private AuditTrail auditTrail;

    /* ===== GETTERS & SETTERS ===== */

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getBillingDate() {
        return billingDate;
    }

    public void setBillingDate(String billingDate) {
        this.billingDate = billingDate;
    }

    public String getJurisdiction() {
        return jurisdiction;
    }

    public void setJurisdiction(String jurisdiction) {
        this.jurisdiction = jurisdiction;
    }

    public double getTotalBaseCharges() {
        return totalBaseCharges;
    }

    public void setTotalBaseCharges(double totalBaseCharges) {
        this.totalBaseCharges = totalBaseCharges;
    }

    public double getTotalDue() {
        return totalDue;
    }

    public void setTotalDue(double totalDue) {
        this.totalDue = totalDue;
    }

    public Map<String, Double> getTaxBreakdown() {
        return taxBreakdown;
    }

    public void setTaxBreakdown(Map<String, Double> taxBreakdown) {
        this.taxBreakdown = taxBreakdown;
    }

    public Map<String, Double> getDeliveryCharges() {
        return deliveryCharges;
    }

    public void setDeliveryCharges(Map<String, Double> deliveryCharges) {
        this.deliveryCharges = deliveryCharges;
    }

    public double getLateFee() {
        return lateFee;
    }

    public void setLateFee(double lateFee) {
        this.lateFee = lateFee;
    }

    public List<MeterOutput> getMeters() {
        return meters;
    }

    public void setMeters(List<MeterOutput> meters) {
        this.meters = meters;
    }

    public AuditTrail getAuditTrail() {
        return auditTrail;
    }

    public void setAuditTrail(AuditTrail auditTrail) {
        this.auditTrail = auditTrail;
    }
}
